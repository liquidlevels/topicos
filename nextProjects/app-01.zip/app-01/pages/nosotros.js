import React from 'react'
import Base from "../components/Base"

const nosotros = () => {
  return (
    <Base>
        hola desde nosotros 
    </Base>
  )
}

export default nosotros