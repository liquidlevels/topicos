import Base from "../components/Base"

const Home = () => {
  return (
    <Base>
      Hola desde inicio
    </Base>
  )
}

export default Home


